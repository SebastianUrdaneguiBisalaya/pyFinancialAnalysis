# pyFinancialAnalysis
This Python package allows you to perform financial analysis with just a few lines of code. It not only focuses on mathematical analysis, but also on visual analysis through graphics. Finally, you can generate a dashboard with the most important statistical elements to make decisions.
